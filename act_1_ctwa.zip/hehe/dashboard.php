<?php
    session_start();

    // Only logged-in users may view the dashboard
    if(!isset($_SESSION['user_id'])){
        header("location: index.php");
        exit();
    }

    function h($str){
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PinkSpace</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>

<nav>
    <div class="logo">Pink<span>Space</span></div>

    <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search inspiration...">
    </div>

    <div class="profile">
        <button class="profile-btn" id="profileBtn" type="button">Profile</button>

        <div class="profile-menu" id="profileMenu">
            <div class="who">Signed in as <?= h($_SESSION['username']); ?></div>
            <?php if(($_SESSION['role'] ?? '') === 'admin'): ?>
                <a href="admin.php">Admin Panel</a>
            <?php endif; ?>
            <a href="index.php?logout=1">Log Out</a>
        </div>
    </div>
</nav>

<header>
    <h1>Discover Beautiful Ideas</h1>
    <p>Your personal inspiration board</p>
</header>

<main class="gallery" id="gallery">

    <div class="card">
        <img src="img/fashion.jpg" alt="Pink Fashion">
        <h3>Pink Fashion</h3>
    </div>

    <div class="card">
        <img src="img/pink1.jpg" alt="Pink Dreams">
        <h3>Pink Dreams</h3>
    </div>

    <div class="card">
        <img src="img/pink1.jpg" alt="Pinky">
        <h3>Pinky</h3>
    </div>

    <div class="card">
        <img src="img/pink2.jpg" alt="Pink Sky">
        <h3>Pink Sky</h3>
    </div>

    <div class="card">
        <img src="img/pink3.jpg" alt="Sabrina">
        <h3>Sabrina</h3>
    </div>

    <div class="card">
        <img src="img/pink4.jpg" alt="Pinkaholic">
        <h3>Pinkaholic</h3>
    </div>

</main>

<p class="empty" id="emptyMsg">No inspiration found.</p>

<script>
const btn = document.getElementById("profileBtn");
const menu = document.getElementById("profileMenu");

btn.addEventListener("click", function(e){
    e.stopPropagation();
    menu.classList.toggle("show");
});

document.addEventListener("click", function(){
    menu.classList.remove("show");
});

menu.addEventListener("click", function(e){
    e.stopPropagation();
});

// Live search over card titles
const input = document.getElementById("searchInput");
const cards = document.querySelectorAll(".card");
const emptyMsg = document.getElementById("emptyMsg");

input.addEventListener("input", function(){
    const q = input.value.trim().toLowerCase();
    let visible = 0;

    cards.forEach(function(card){
        const title = card.querySelector("h3").textContent.toLowerCase();
        const match = title.includes(q);
        card.style.display = match ? "" : "none";
        if(match) visible++;
    });

    emptyMsg.style.display = visible === 0 ? "block" : "none";
});
</script>

</body>
</html>
