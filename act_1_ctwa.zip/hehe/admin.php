<?php
    session_start();
    require_once "config.php";

    // Admins only
    if(!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin'){
        header("location: index.php");
        exit();
    }

    function h($str){
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }

    if(empty($_SESSION['csrf'])){
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }

    $notice = "";

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $token = $_POST['csrf'] ?? '';
        $id = (int)($_POST['id'] ?? 0);
        $action = $_POST['action'] ?? '';

        if(!hash_equals($_SESSION['csrf'], $token)){
            $notice = "Invalid request. Please try again.";
        } elseif($id === (int)$_SESSION['user_id']){
            $notice = "You can't change your own account here.";
        } elseif($action === 'approve'){
            $stmt = $conn->prepare("UPDATE users SET status='approved' WHERE id=?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            $notice = "User approved.";
        } elseif($action === 'revoke'){
            $stmt = $conn->prepare("UPDATE users SET status='pending' WHERE id=?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            $notice = "Access revoked.";
        } elseif($action === 'delete'){
            $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
            $notice = "User deleted.";
        }
    }

    $users = [];
    $res = $conn->query("SELECT id, username, role, status FROM users ORDER BY (status='pending') DESC, id ASC");
    if($res){
        while($row = $res->fetch_assoc()){
            $users[] = $row;
        }
    }

    $pending = 0;
    foreach($users as $u){
        if($u['status'] !== 'approved') $pending++;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | PinkSpace</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>

<nav>
    <div class="logo">Pink<span>Space</span> <small>Admin</small></div>
    <div class="nav-links">
        <a href="dashboard.php">View Site</a>
        <a href="index.php?logout=1">Log Out</a>
    </div>
</nav>

<main class="wrap">

    <h1>Hello, <?= h($_SESSION['username']); ?></h1>
    <p class="sub">Approve new members and manage who can access PinkSpace.</p>

    <div class="stats">
        <div class="stat"><strong><?= count($users); ?></strong><span>Total users</span></div>
        <div class="stat"><strong><?= $pending; ?></strong><span>Waiting for approval</span></div>
    </div>

    <?php if($notice !== ""): ?>
        <div class="notice"><?= h($notice); ?></div>
    <?php endif; ?>

    <div class="table-card">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($users as $u): ?>
                <tr>
                    <td><?= h($u['username']); ?></td>
                    <td><?= h($u['role']); ?></td>
                    <td>
                        <span class="badge <?= $u['status'] === 'approved' ? 'ok' : 'wait'; ?>">
                            <?= h($u['status']); ?>
                        </span>
                    </td>
                    <td>
                        <?php if((int)$u['id'] === (int)$_SESSION['user_id']): ?>
                            <em>You</em>
                        <?php else: ?>
                            <form method="POST" class="inline">
                                <input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']); ?>">
                                <input type="hidden" name="id" value="<?= (int)$u['id']; ?>">
                                <?php if($u['status'] !== 'approved'): ?>
                                    <button name="action" value="approve" class="b-ok">Approve</button>
                                <?php else: ?>
                                    <button name="action" value="revoke" class="b-warn">Revoke</button>
                                <?php endif; ?>
                                <button name="action" value="delete" class="b-del"
                                        onclick="return confirm('Delete this user?');">Delete</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if(count($users) === 0): ?>
                <tr><td colspan="4" class="none">No users yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</main>

</body>
</html>
