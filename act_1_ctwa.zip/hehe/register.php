<?php
    require_once "config.php";

    function h($str){
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }

    $mess = [];
    $errors = [];

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $uname = trim($_POST['uname'] ?? '');
        $password = $_POST['password'] ?? '';
        $password2 = $_POST['password2'] ?? '';

        if($uname === '' || strlen($uname) > 50){
            $errors[] = "Username must be between 1 and 50 characters.";
        } elseif(strlen($password) < 6){
            $errors[] = "Password must be at least 6 characters.";
        } elseif($password !== $password2){
            $errors[] = "Passwords should match.";
        } else {

            // Stop duplicate usernames
            $check = $conn->prepare("SELECT id FROM users WHERE username=?");
            $check->bind_param('s', $uname);
            $check->execute();
            $check->store_result();
            $exists = $check->num_rows > 0;
            $check->close();

            if($exists){
                $errors[] = "That username is already taken.";
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $role = 'user';
                $status = 'pending';

                $stmt = $conn->prepare("INSERT INTO users (username, password, role, status) VALUES (?, ?, ?, ?)");
                $stmt->bind_param('ssss', $uname, $hash, $role, $status);
                $stmt->execute();

                if($stmt->affected_rows > 0){
                    $mess[] = "Registered successfully. Please wait for admin approval.";
                } else {
                    $errors[] = "Something went wrong. Please try again later.";
                }

                $stmt->close();
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Register | PinkSpace</title>
</head>
<body>

<div class="container">

    <section class="hero">
        <div class="brand">Pink<span>Space</span></div>
        <div>
            <h1>Start your own pink universe.</h1>
            <p>Create an account and an admin will approve you shortly.</p>
        </div>
    </section>

    <section class="panel">
        <div class="card">

            <h2>Create account</h2>
            <p class="subtitle">Join PinkSpace today</p>

            <?php foreach ($mess as $m): ?>
                <div class="message"><?= h($m); ?></div>
            <?php endforeach; ?>

            <?php foreach ($errors as $e): ?>
                <div class="error"><?= h($e); ?></div>
            <?php endforeach; ?>

            <form method="POST">

                <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="uname" maxlength="50" value="<?= h($_POST['uname'] ?? ''); ?>" required>
                </div>

                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" minlength="6" required>
                </div>

                <div class="input-group">
                    <label>Confirm Password</label>
                    <input type="password" name="password2" minlength="6" required>
                </div>

                <button type="submit" class="btn">Create Account</button>

            </form>

            <div class="link">
                Already have an account?
                <a href="index.php">Sign In</a>
            </div>

        </div>
    </section>

</div>

</body>
</html>
