<?php
    session_start();
    require_once "config.php";

    // Log out: clear the session when arriving with ?logout=1
    if(isset($_GET['logout'])){
        $_SESSION = [];
        session_destroy();
        header("location: index.php");
        exit();
    }

    // Already signed in? Go straight to the right page.
    if(isset($_SESSION['user_id'])){
        header("location: " . (($_SESSION['role'] ?? '') === 'admin' ? "admin.php" : "dashboard.php"));
        exit();
    }

    function h($str){
        return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
    }

    $errors = [];

    if($_SERVER['REQUEST_METHOD'] === 'POST'){
        $uname = trim($_POST['uname'] ?? '');
        $password = $_POST['password'] ?? '';

        $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
        $stmt->bind_param('s', $uname);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $stmt->close();

        $valid = false;

        if($user){
            if(password_verify($password, $user['password'])){
                $valid = true;
            } elseif(hash_equals((string)$user['password'], $password)){
                // Old plain-text password: accept once, then upgrade it to a hash
                $valid = true;
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $up = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $up->bind_param('si', $newHash, $user['id']);
                $up->execute();
                $up->close();
            }
        }

        if($valid){
            if($user['status'] !== "approved"){
                $errors[] = "Your account has not been approved by the admin.";
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                header("location: " . ($user['role'] === 'admin' ? "admin.php" : "dashboard.php"));
                exit();
            }
        } else {
            $errors[] = "Invalid username or password.";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>Sign In | PinkSpace</title>
</head>
<body>

<div class="container">

    <section class="hero">
        <div class="brand">Pink<span>Space</span></div>
        <div>
            <h1>Where pink ideas find a home.</h1>
            <p>Collect, browse and get lost in the prettiest inspiration on the internet.</p>
        </div>
    </section>

    <section class="panel">
        <div class="card">

            <h2>Welcome back</h2>
            <p class="subtitle">Sign in to continue to PinkSpace</p>

            <?php foreach ($errors as $e): ?>
                <div class="error"><?= h($e); ?></div>
            <?php endforeach; ?>

            <form method="POST">

                <div class="input-group">
                    <label>Username</label>
                    <input type="text" name="uname" value="<?= h($_POST['uname'] ?? ''); ?>" required>
                </div>

                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>

                <button type="submit" class="btn">Sign In</button>

            </form>

            <div class="link">
                No account?
                <a href="register.php">Register</a>
            </div>

        </div>
    </section>

</div>

</body>
</html>
