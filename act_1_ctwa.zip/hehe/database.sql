CREATE DATABASE IF NOT EXISTS pink_db CHARACTER SET utf8mb4;
USE pink_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Starter admin account. The plain password is converted to a secure hash
-- automatically the first time you sign in. Change it afterwards.
INSERT IGNORE INTO users (username, password, role, status)
VALUES ('admin', 'admin123', 'admin', 'approved');

-- If your users table already exists, run these instead:
-- ALTER TABLE users MODIFY password VARCHAR(255) NOT NULL;
-- ALTER TABLE users MODIFY role VARCHAR(20) NOT NULL DEFAULT 'user';
-- ALTER TABLE users MODIFY status VARCHAR(20) NOT NULL DEFAULT 'pending';
