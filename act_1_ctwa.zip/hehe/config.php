<?php

    mysqli_report(MYSQLI_REPORT_OFF);

    $conn = @mysqli_connect("localhost","root","","pink_db");

    if(!$conn){
        http_response_code(500);
        die("Database connection failed. Make sure MySQL is running and that the 'pink_db' database exists (import database.sql in phpMyAdmin).");
    }

    mysqli_set_charset($conn, "utf8mb4");

    // Make sure the users table exists and its password column is long enough for hashes
    $colCheck = $conn->query("SELECT CHARACTER_MAXIMUM_LENGTH AS len FROM information_schema.COLUMNS
                              WHERE TABLE_SCHEMA='pink_db' AND TABLE_NAME='users' AND COLUMN_NAME='password'");
    $colRow = $colCheck ? $colCheck->fetch_assoc() : null;

    if(!$colRow){
        http_response_code(500);
        die("The 'users' table was not found in pink_db. Import database.sql in phpMyAdmin.");
    }

    if($colRow['len'] !== null && (int)$colRow['len'] < 255){
        $conn->query("ALTER TABLE users MODIFY password VARCHAR(255) NOT NULL");
    }

?>
